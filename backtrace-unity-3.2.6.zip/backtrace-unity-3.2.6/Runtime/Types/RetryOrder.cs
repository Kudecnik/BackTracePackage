﻿namespace Backtrace.Unity.Types
{
    public enum RetryOrder
    {
        Stack,Queue
    }
}
