﻿namespace Backtrace.Unity.Types
{
    public enum RetryBehavior
    {
        ByInterval,
        NoRetry
    }
}